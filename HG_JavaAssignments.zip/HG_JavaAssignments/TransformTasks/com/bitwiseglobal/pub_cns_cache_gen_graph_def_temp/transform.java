package com.bitwiseglobal.pub_cns_cache_gen_graph_def_temp;

import java.util.List;
import java.util.Properties;

import hg.component.common.base.schema.Field;
import hydrograph.engine.spark.components.reusablerow.ReusableRow;
import hydrograph.engine.transformation.base.TransformBase;

public class transform implements TransformBase {

	@Override
	public void cleanup() {
		// TODO Auto-generated method stub

	}

	@Override
	public void prepare(Properties arg0, List<Field> arg1, List<Field> arg2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void transform(ReusableRow arg0, ReusableRow arg1) {
		// TODO Auto-generated method stub

	}

}
