import java.util.ArrayList;
import java.util.Properties;
import hydrograph.engine.aggregate.base.AggregateTransformBase;
import hydrograph.engine.spark.components.reusablerow.ReusableRow;

public class AggregateSampleClass implements AggregateTransformBase {
		
	@Override
	public void aggregate(ReusableRow arg0) {	
	}

	@Override
	public void cleanup() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onCompleteGroup(ReusableRow arg0) { //output set
	
	}

	@Override
	public void prepare(Properties arg0, ArrayList<String> arg1, ArrayList<String> arg2, ArrayList<String> arg3) {
		// TODO Auto-generated method stub

	}

}
